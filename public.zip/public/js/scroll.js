$(document).ready(function() {
    $("#view-map").click(function () {
        $('html,body').animate({
            scrollTop: 1520
        }, 500);
    });

    $("#view-form").click(function () {
        $('html,body').animate({
            scrollTop: 1920
        }, 500);
    });

    $("#view-social").click(function () {
        $('html,body').animate({
            scrollTop: 710
        }, 500);
    });

});
