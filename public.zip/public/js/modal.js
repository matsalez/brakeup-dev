window.onload = function () {
    document.getElementById('button-close-modal').onclick = function () {
        document.getElementById('modal').style.display = "none"
        };
        document.getElementById('button-form-modal-no').onclick = function () {
            document.getElementById('modal').style.display = "none"
        };

};
